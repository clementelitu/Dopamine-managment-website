﻿const SITES = [
    { key: "youtube", name: "YouTube", icon: "▶️" },
    { key: "linkedin", name: "LinkedIn", icon: "💼" },
    { key: "netflix", name: "Netflix", icon: "🎬" }
];

function todayKey() {
    const d = new Date();
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
}

function msToHMS(ms) {
    const totalSec = Math.max(0, Math.floor(ms / 1000));
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;

    if (h > 0) return `${h}h ${m}m ${s}s`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
}

function clampNumber(n, min, max) {
    if (Number.isNaN(n)) return min;
    return Math.min(max, Math.max(min, n));
}

function getDefaultBudgets() {
    return {
        youtube: { minutes: 60, visits: 10 },
        linkedin: { minutes: 30, visits: 10 },
        netflix: { minutes: 45, visits: 5 }
    };
}

function emptyStats(dateStr) {
    const base = { date: dateStr };
    for (const s of SITES) base[s.key] = { activeMs: 0, visits: 0 };
    return base;
}

function emptyExtrasForDate() {
    const base = {};
    for (const s of SITES) base[s.key] = { minutes: 0, visits: 0 };
    return base;
}

async function getAllState(overrideTodayStats = null) {
    const dateStr = todayKey();
    const data = await chrome.storage.local.get(["defaultBudgets", "dailyExtras", "todayStats"]);

    const defaultBudgets = data.defaultBudgets ?? getDefaultBudgets();
    const dailyExtras = data.dailyExtras ?? {};
    let todayStats = overrideTodayStats ?? data.todayStats;

    // Popup never overwrites stats.
    if (!todayStats || todayStats.date !== dateStr) {
        todayStats = emptyStats(dateStr);
    }

    // Popup can initialize extras
    if (!dailyExtras[dateStr]) {
        dailyExtras[dateStr] = emptyExtrasForDate();
        await chrome.storage.local.set({ dailyExtras });
    }

    return { dateStr, defaultBudgets, dailyExtras, todayStats };
}

function pctUsed(active, allocated) {
    if (allocated <= 0) return 100;
    return clampNumber(Math.round((active / allocated) * 100), 0, 999);
}

function makeRow(site, state) {
    const { key, name, icon } = site;

    const stats = state.todayStats[key] ?? { activeMs: 0, visits: 0 };
    const defaults = state.defaultBudgets[key] ?? { minutes: 0, visits: 0 };
    const extras = state.dailyExtras[state.dateStr]?.[key] ?? { minutes: 0, visits: 0 };

    const allocatedMinutes = (defaults.minutes ?? 0) + (extras.minutes ?? 0);
    const allocatedVisits = (defaults.visits ?? 0) + (extras.visits ?? 0);

    const activeMs = stats.activeMs ?? 0;
    const activeMinutesFloat = activeMs / 60000;
    const activeVisits = stats.visits ?? 0;

    const remainingMinutes = allocatedMinutes - activeMinutesFloat;
    const remainingVisits = allocatedVisits - activeVisits;

    const usedMinPct = pctUsed(activeMinutesFloat, allocatedMinutes);
    const usedVisitPct = pctUsed(activeVisits, allocatedVisits);

    let stateClass = "state-good";
    if (remainingMinutes < 0 || remainingVisits < 0) stateClass = "state-bad";
    else {
        const minLeftPct = allocatedMinutes > 0 ? (remainingMinutes / allocatedMinutes) * 100 : 0;
        const visitLeftPct = allocatedVisits > 0 ? (remainingVisits / allocatedVisits) * 100 : 0;
        if (minLeftPct <= 20 || visitLeftPct <= 20) stateClass = "state-warn";
    }

    const tr = document.createElement("tr");
    tr.dataset.site = key;

    tr.innerHTML = `
    <td>
      <div class="site">
        <div class="badge" aria-hidden="true">${icon}</div>
        <div>
          <div><strong>${name}</strong></div>
          <div class="small">${key}</div>
        </div>
      </div>
    </td>

    <td>
      <div><strong>${msToHMS(activeMs)}</strong></div>
      <div class="small">${activeMinutesFloat.toFixed(2)} min</div>
    </td>

    <td>
      <div><strong>${activeVisits}</strong></div>
      <div class="small">visits</div>
    </td>

    <td>
      <input class="input" type="number" min="0" max="1440" step="5"
        value="${defaults.minutes ?? 0}"
        data-field="defaultMinutes"
        aria-label="${name} allocated minutes (default)" />
      <div class="small">+${extras.minutes ?? 0} today</div>
    </td>

    <td>
      <input class="input" type="number" min="0" max="999" step="1"
        value="${defaults.visits ?? 0}"
        data-field="defaultVisits"
        aria-label="${name} allocated visits (default)" />
      <div class="small">+${extras.visits ?? 0} today</div>
    </td>

    <td>
      <div class="remaining">
        <div class="pill ${stateClass}">
          <span><strong>${remainingMinutes.toFixed(2)}</strong> min left</span>
          <span class="bar"><span class="fill" style="width:${clampNumber(usedMinPct, 0, 100)}%"></span></span>
          <span class="small">${usedMinPct}%</span>
        </div>
        <div class="pill ${stateClass}">
          <span><strong>${remainingVisits}</strong> visits left</span>
          <span class="bar"><span class="fill" style="width:${clampNumber(usedVisitPct, 0, 100)}%"></span></span>
          <span class="small">${usedVisitPct}%</span>
        </div>
      </div>
    </td>

    <td>
      <button class="btn" data-action="extend">Extend</button>
      <div class="small">for today</div>
    </td>
  `;

    return tr;
}

async function render(overrideTodayStats = null) {
    const state = await getAllState(overrideTodayStats);
    document.getElementById("todayLabel").textContent = `Today • ${state.dateStr}`;

    const tbody = document.getElementById("rows");
    tbody.innerHTML = "";

    for (const site of SITES) {
        tbody.appendChild(makeRow(site, state));
    }
}

function debounce(fn, ms) {
    let t = null;
    return (...args) => {
        clearTimeout(t);
        t = setTimeout(() => fn(...args), ms);
    };
}

const saveBudgetDebounced = debounce(async (siteKey, updates) => {
    const data = await chrome.storage.local.get(["defaultBudgets"]);
    const defaultBudgets = data.defaultBudgets ?? getDefaultBudgets();

    defaultBudgets[siteKey] ??= { minutes: 0, visits: 0 };

    if (typeof updates.minutes === "number") defaultBudgets[siteKey].minutes = updates.minutes;
    if (typeof updates.visits === "number") defaultBudgets[siteKey].visits = updates.visits;

    await chrome.storage.local.set({ defaultBudgets });
    await render();
}, 250);

async function extendForToday(siteKey) {
    const dateStr = todayKey();
    const { dailyExtras } = await chrome.storage.local.get(["dailyExtras"]);
    const extras = dailyExtras ?? {};

    if (!extras[dateStr]) extras[dateStr] = emptyExtrasForDate();
    extras[dateStr][siteKey] ??= { minutes: 0, visits: 0 };

    const addMinStr = prompt("Add extra minutes for today:", "15");
    if (addMinStr === null) return;

    const addVisitsStr = prompt("Add extra visits for today:", "1");
    if (addVisitsStr === null) return;

    const addMinutes = clampNumber(parseInt(addMinStr, 10), 0, 1440);
    const addVisits = clampNumber(parseInt(addVisitsStr, 10), 0, 999);

    extras[dateStr][siteKey].minutes += addMinutes;
    extras[dateStr][siteKey].visits += addVisits;

    await chrome.storage.local.set({ dailyExtras: extras });
    await render();
}

// ✅ NEW: Reset via background so stored usageByDay is wiped.
async function resetTodayStats() {
    try {
        const res = await chrome.runtime.sendMessage({ type: "RESET_TODAY" });
        if (res?.ok && res?.todayStats) {
            await render(res.todayStats);
            return;
        }
    } catch { }
    // fallback: just re-render
    await render();
}

// --------------------
// LIVE connection to background
// --------------------
let port = null;

function startLiveConnection() {
    try {
        port = chrome.runtime.connect({ name: "popup-live" });

        port.onMessage.addListener((msg) => {
            if (msg?.type === "LIVE_STATS") {
                const ts = msg.payload?.todayStats;
                if (ts) render(ts);
            }
        });

        port.onDisconnect.addListener(() => {
            port = null;
        });
    } catch {
        port = null;
    }
}

async function syncOnce() {
    try {
        const res = await chrome.runtime.sendMessage({ type: "POPUP_SYNC" });
        if (res?.todayStats) await render(res.todayStats);
        else await render();
    } catch {
        await render();
    }
}

// --------------------
// UI events
// --------------------
document.addEventListener("input", (e) => {
    const el = e.target;
    if (!(el instanceof HTMLInputElement)) return;
    if (!el.classList.contains("input")) return;

    const tr = el.closest("tr");
    if (!tr) return;

    const siteKey = tr.dataset.site;
    const field = el.dataset.field;
    if (!siteKey || !field) return;

    if (field === "defaultMinutes") {
        const minutes = clampNumber(parseInt(el.value, 10), 0, 1440);
        saveBudgetDebounced(siteKey, { minutes });
    }

    if (field === "defaultVisits") {
        const visits = clampNumber(parseInt(el.value, 10), 0, 999);
        saveBudgetDebounced(siteKey, { visits });
    }
});

document.addEventListener("click", (e) => {
    const el = e.target;
    if (!(el instanceof HTMLElement)) return;

    if (el.id === "resetTodayBtn") {
        resetTodayStats();
        return;
    }

    if (el.dataset.action === "extend") {
        const tr = el.closest("tr");
        const siteKey = tr?.dataset.site;
        if (siteKey) extendForToday(siteKey);
    }
});

chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes.defaultBudgets || changes.dailyExtras) render();
});

// Start
syncOnce();
startLiveConnection();
