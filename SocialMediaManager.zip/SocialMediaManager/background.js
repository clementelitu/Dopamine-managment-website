﻿// background.js (MV3 service worker)
//
// Features:
// - Counts time if ANY tracked-site tab is open in Chrome
// - Live updates to popup via Port ("popup-live")
// - Cooldowns:
//    * temp (15 min) when time >= allocated AND visits < allocatedVisits
//    * eod (until midnight) when time >= allocated AND visits >= allocatedVisits
// - Enforcement:
//    * Sends COOLDOWN_STATUS to content script (overlay + countdown + pause attempt)
//    * Mutes YouTube/Netflix tabs as backup while cooldown active
// - Injection fix:
//    * If overlay doesn't apply immediately in already-open tabs, auto-inject cooldown_content.js via chrome.scripting
// - NEW RULE (your request):
//    * If a site is on cooldown, we DO NOT add active time for that site while cooldown is active.

const LIVE_PUSH_MS = 1000;
const PAUSE_WHEN_UNFOCUSED = false;

const TEMP_COOLDOWN_MS = 15 * 60 * 1000;
const ALARM_NAME = "timebudget-tick";
const ALARM_PERIOD_MINUTES = 0.5;

const SITES = [
    { key: "youtube", hosts: ["youtube.com", "www.youtube.com", "m.youtube.com", "youtu.be"], canMute: true },
    { key: "linkedin", hosts: ["linkedin.com", "www.linkedin.com"], canMute: false },
    { key: "netflix", hosts: ["netflix.com", "www.netflix.com"], canMute: true }
];

function todayKey() {
    const d = new Date();
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
}

function emptyDayRecord() {
    const rec = {};
    for (const s of SITES) rec[s.key] = { activeMs: 0, visits: 0 };
    return rec;
}

function emptyCooldownDay() {
    const rec = {};
    for (const s of SITES) rec[s.key] = { active: false, type: null, endsAt: 0 };
    return rec;
}

function nextMidnightMs() {
    const d = new Date();
    const next = new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1, 0, 0, 0, 0);
    return next.getTime();
}

function getSiteKeyFromUrl(url) {
    if (!url) return null;
    let u;
    try {
        u = new URL(url);
    } catch {
        return null;
    }
    const host = u.hostname.toLowerCase();
    for (const s of SITES) {
        for (const h of s.hosts) {
            if (host === h || host.endsWith("." + h)) return s.key;
        }
    }
    return null;
}

// --------------------
// In-memory session state
// --------------------
const state = {
    windowFocused: true,
    idleState: "active",
    lastTickMs: Date.now(),
    openSitesLastTick: new Set(),
    perTabLastSite: new Map(),
    lastTrackedTabCount: 0,

    // ✅ NEW: snapshot of today’s cooldown states for fast checking in tickNow()
    cooldownCache: null
};

// Serialize async handlers
let lock = Promise.resolve();
function withLock(fn) {
    lock = lock.then(fn).catch((e) => console.error("TimeBudget error:", e));
    return lock;
}

function canCountNow() {
    const focusOk = PAUSE_WHEN_UNFOCUSED ? state.windowFocused : true;
    return focusOk && state.idleState === "active";
}

// --------------------
// Cooldown cache helpers (NEW)
// --------------------
function cloneCooldownDay(cdDay) {
    const out = {};
    for (const s of SITES) {
        const v = cdDay?.[s.key] ?? { active: false, type: null, endsAt: 0 };
        out[s.key] = {
            active: !!v.active,
            type: v.type ?? null,
            endsAt: Number(v.endsAt ?? 0)
        };
    }
    return out;
}

function isSiteOnCooldown(siteKey, nowMs) {
    const cd = state.cooldownCache?.[siteKey];
    return !!(cd && cd.active && cd.endsAt > nowMs);
}

// --------------------
// Storage helpers
// --------------------
function getDefaultBudgets() {
    return {
        youtube: { minutes: 60, visits: 10 },
        linkedin: { minutes: 30, visits: 10 },
        netflix: { minutes: 45, visits: 5 }
    };
}

function emptyExtrasForDate() {
    const base = {};
    for (const s of SITES) base[s.key] = { minutes: 0, visits: 0 };
    return base;
}

async function loadAll() {
    const data = await chrome.storage.local.get([
        "usageByDay",
        "todayStats",
        "defaultBudgets",
        "dailyExtras",
        "cooldownsByDay"
    ]);

    return {
        usageByDay: data.usageByDay ?? {},
        todayStats: data.todayStats ?? null,
        defaultBudgets: data.defaultBudgets ?? getDefaultBudgets(),
        dailyExtras: data.dailyExtras ?? {},
        cooldownsByDay: data.cooldownsByDay ?? {}
    };
}

async function saveAll(patch) {
    await chrome.storage.local.set(patch);
}

async function ensureTodayRecords() {
    const dateStr = todayKey();
    const { usageByDay, dailyExtras, cooldownsByDay } = await loadAll();

    if (!usageByDay[dateStr]) usageByDay[dateStr] = emptyDayRecord();
    if (!dailyExtras[dateStr]) dailyExtras[dateStr] = emptyExtrasForDate();
    if (!cooldownsByDay[dateStr]) cooldownsByDay[dateStr] = emptyCooldownDay();

    // ✅ keep cache synced (NEW)
    state.cooldownCache = cloneCooldownDay(cooldownsByDay[dateStr]);

    const todayStats = { date: dateStr, ...usageByDay[dateStr] };

    await saveAll({ usageByDay, todayStats, dailyExtras, cooldownsByDay });
    return { dateStr, usageByDay, dailyExtras, cooldownsByDay, todayStats };
}

async function addActiveMs(siteKey, deltaMs) {
    if (!siteKey || deltaMs <= 0) return;

    const dateStr = todayKey();
    const { usageByDay } = await loadAll();
    if (!usageByDay[dateStr]) usageByDay[dateStr] = emptyDayRecord();

    usageByDay[dateStr][siteKey] ??= { activeMs: 0, visits: 0 };
    usageByDay[dateStr][siteKey].activeMs += deltaMs;

    const todayStats = { date: dateStr, ...usageByDay[dateStr] };
    await saveAll({ usageByDay, todayStats });
}

async function addVisit(siteKey) {
    if (!siteKey) return;

    const dateStr = todayKey();
    const { usageByDay } = await loadAll();
    if (!usageByDay[dateStr]) usageByDay[dateStr] = emptyDayRecord();

    usageByDay[dateStr][siteKey] ??= { activeMs: 0, visits: 0 };
    usageByDay[dateStr][siteKey].visits += 1;

    const todayStats = { date: dateStr, ...usageByDay[dateStr] };
    await saveAll({ usageByDay, todayStats });
}

// --------------------
// Script injection fix
// --------------------
async function ensureCooldownContentScript(tabId) {
    try {
        await chrome.scripting.executeScript({
            target: { tabId },
            files: ["cooldown_content.js"]
        });
        return true;
    } catch {
        return false;
    }
}

async function injectIntoAllTrackedTabs() {
    const tabs = await chrome.tabs.query({}).catch(() => []);
    for (const tab of tabs) {
        const siteKey = getSiteKeyFromUrl(tab.url);
        if (!siteKey) continue;
        await ensureCooldownContentScript(tab.id);
    }
}

// --------------------
// Tab scanning / timing
// --------------------
async function computeOpenTrackedSites() {
    const tabs = await chrome.tabs.query({}).catch(() => []);
    const openSites = new Set();
    let trackedCount = 0;

    for (const tab of tabs) {
        const siteKey = getSiteKeyFromUrl(tab.url);
        if (siteKey) {
            trackedCount += 1;
            openSites.add(siteKey);
        }
    }
    return { trackedCount, openSites };
}

// ✅ UPDATED: tickNow now skips sites on cooldown
async function tickNow() {
    const now = Date.now();
    const delta = now - (state.lastTickMs || now);

    if (delta > 0 && canCountNow() && state.openSitesLastTick.size > 0) {
        for (const siteKey of state.openSitesLastTick) {
            // NEW RULE: do not count time while on cooldown
            if (isSiteOnCooldown(siteKey, now)) continue;
            await addActiveMs(siteKey, delta);
        }
    }

    state.lastTickMs = now;
}

async function startTickAlarm() {
    chrome.alarms.create(ALARM_NAME, { periodInMinutes: ALARM_PERIOD_MINUTES });
}

async function stopTickAlarm() {
    await chrome.alarms.clear(ALARM_NAME);
}

async function evaluateTabsAndTiming(reason = "evaluate") {
    await ensureTodayRecords();
    await tickNow();

    const { trackedCount, openSites } = await computeOpenTrackedSites();

    if (state.lastTrackedTabCount === 0 && trackedCount > 0) {
        await startTickAlarm();
        state.lastTickMs = Date.now();
    } else if (state.lastTrackedTabCount > 0 && trackedCount === 0) {
        await stopTickAlarm();
        state.lastTickMs = Date.now();
    }

    state.lastTrackedTabCount = trackedCount;
    state.openSitesLastTick = openSites;
}

// --------------------
// Cooldown logic
// --------------------
function computeCooldownForSite({ usedMs, usedVisits, allocatedMinutes, allocatedVisits, existing }) {
    const now = Date.now();
    const usedMinutes = usedMs / 60000;

    // Keep active cooldown until it expires
    if (existing?.active && typeof existing.endsAt === "number" && existing.endsAt > now) {
        return existing;
    }

    // If time not exceeded -> no cooldown
    if (usedMinutes < allocatedMinutes) {
        return { active: false, type: null, endsAt: 0 };
    }

    // Time exceeded:
    // temp cooldown if visits still available
    if (usedVisits < allocatedVisits) {
        return { active: true, type: "temp", endsAt: now + TEMP_COOLDOWN_MS };
    }

    // end-of-day cooldown
    return { active: true, type: "eod", endsAt: nextMidnightMs() };
}

async function evaluateCooldownsAndEnforce(reason = "cooldowns") {
    const dateStr = todayKey();
    const { usageByDay, defaultBudgets, dailyExtras, cooldownsByDay } = await loadAll();

    if (!usageByDay[dateStr]) return;

    cooldownsByDay[dateStr] ??= emptyCooldownDay();
    dailyExtras[dateStr] ??= emptyExtrasForDate();

    const dayUsage = usageByDay[dateStr];
    const dayExtras = dailyExtras[dateStr];

    let changed = false;

    for (const site of SITES) {
        const usedMs = dayUsage?.[site.key]?.activeMs ?? 0;
        const usedVisits = dayUsage?.[site.key]?.visits ?? 0;

        const base = defaultBudgets?.[site.key] ?? { minutes: 0, visits: 0 };
        const extra = dayExtras?.[site.key] ?? { minutes: 0, visits: 0 };

        const allocatedMinutes = (base.minutes ?? 0) + (extra.minutes ?? 0);
        const allocatedVisits = (base.visits ?? 0) + (extra.visits ?? 0);

        const existing = cooldownsByDay[dateStr]?.[site.key] ?? { active: false, type: null, endsAt: 0 };
        const next = computeCooldownForSite({ usedMs, usedVisits, allocatedMinutes, allocatedVisits, existing });

        const normalized = {
            active: !!next.active,
            type: next.active ? next.type : null,
            endsAt: next.active ? next.endsAt : 0
        };

        const prevSig = JSON.stringify(cooldownsByDay[dateStr][site.key] ?? null);
        const nextSig = JSON.stringify(normalized);

        if (prevSig !== nextSig) {
            cooldownsByDay[dateStr][site.key] = normalized;
            changed = true;
        }

        await enforceCooldownOnTabs(site.key, normalized);
    }

    if (changed) {
        await saveAll({ cooldownsByDay });
    }

    // ✅ NEW: refresh in-memory cache every evaluation (so tickNow can skip cooldown sites)
    state.cooldownCache = cloneCooldownDay(cooldownsByDay[dateStr]);
}

async function enforceCooldownOnTabs(siteKey, cooldown) {
    const tabs = await chrome.tabs.query({}).catch(() => []);
    const site = SITES.find((s) => s.key === siteKey);

    for (const tab of tabs) {
        const tabSite = getSiteKeyFromUrl(tab.url);
        if (tabSite !== siteKey) continue;

        // 1) Try send message
        let delivered = false;
        try {
            await chrome.tabs.sendMessage(tab.id, {
                type: "COOLDOWN_STATUS",
                payload: { ...cooldown, siteKey }
            });
            delivered = true;
        } catch {
            // no listener
        }

        // 2) If not delivered, inject CS then retry once
        if (!delivered) {
            const injected = await ensureCooldownContentScript(tab.id);
            if (injected) {
                try {
                    await chrome.tabs.sendMessage(tab.id, {
                        type: "COOLDOWN_STATUS",
                        payload: { ...cooldown, siteKey }
                    });
                } catch { }
            }
        }

        // 3) Mute/unmute as backup on sites that support it
        if (site?.canMute) {
            try {
                await chrome.tabs.update(tab.id, { muted: !!cooldown.active });
            } catch { }
        }
    }
}

// --------------------
// Visits tracking
// --------------------
async function maybeCountVisit(tabId, newUrl) {
    const newSite = getSiteKeyFromUrl(newUrl);
    const oldSite = state.perTabLastSite.get(tabId) ?? null;

    if (newSite && newSite !== oldSite) {
        await addVisit(newSite);
    }
    state.perTabLastSite.set(tabId, newSite);
}

async function primeTabMap() {
    const tabs = await chrome.tabs.query({}).catch(() => []);
    state.perTabLastSite.clear();
    for (const t of tabs) state.perTabLastSite.set(t.id, getSiteKeyFromUrl(t.url));
}

// --------------------
// Messaging
// --------------------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg?.type) return;

    // Popup sync
    if (msg.type === "POPUP_SYNC") {
        withLock(async () => {
            await evaluateTabsAndTiming("popupSync");
            await evaluateCooldownsAndEnforce("popupSyncCooldowns");

            const dateStr = todayKey();
            const { todayStats, cooldownsByDay } = await loadAll();

            sendResponse({
                ok: true,
                todayStats: todayStats ?? null,
                cooldowns: cooldownsByDay?.[dateStr] ?? {},
                paused: !canCountNow()
            });
        });
        return true;
    }

    // Debug reset (wipe today usage + cooldowns)
    if (msg.type === "RESET_TODAY") {
        withLock(async () => {
            const dateStr = todayKey();
            const { usageByDay, cooldownsByDay } = await loadAll();

            usageByDay[dateStr] = emptyDayRecord();
            cooldownsByDay[dateStr] = emptyCooldownDay();

            const todayStats = { date: dateStr, ...usageByDay[dateStr] };
            await saveAll({ usageByDay, todayStats, cooldownsByDay });

            // ✅ keep cache synced (NEW)
            state.cooldownCache = cloneCooldownDay(cooldownsByDay[dateStr]);

            state.lastTickMs = Date.now();

            // Clear overlays immediately
            for (const site of SITES) {
                await enforceCooldownOnTabs(site.key, { active: false, type: null, endsAt: 0 });
            }

            sendResponse({ ok: true, todayStats });
        });
        return true;
    }

    // Content script requests current status
    if (msg.type === "GET_COOLDOWN_STATUS_FOR_THIS_TAB") {
        withLock(async () => {
            const tabId = sender?.tab?.id;
            const url = sender?.tab?.url;
            const siteKey = getSiteKeyFromUrl(url);

            if (!tabId || !siteKey) {
                sendResponse({ ok: true, payload: { active: false, type: null, endsAt: 0 } });
                return;
            }

            const dateStr = todayKey();
            const { cooldownsByDay } = await loadAll();
            const cd = cooldownsByDay?.[dateStr]?.[siteKey] ?? { active: false, type: null, endsAt: 0 };

            await ensureCooldownContentScript(tabId);

            sendResponse({ ok: true, payload: { ...cd, siteKey } });

            try {
                await chrome.tabs.sendMessage(tabId, { type: "COOLDOWN_STATUS", payload: { ...cd, siteKey } });
            } catch { }
        });
        return true;
    }
});

// --------------------
// Live Port to popup
// --------------------
const livePorts = new Set();
let liveIntervalId = null;

function startLiveLoopIfNeeded() {
    if (liveIntervalId) return;

    liveIntervalId = setInterval(() => {
        withLock(async () => {
            await evaluateTabsAndTiming("live");
            await evaluateCooldownsAndEnforce("liveCooldowns");

            const dateStr = todayKey();
            const { todayStats, cooldownsByDay } = await loadAll();
            const payload = {
                todayStats: todayStats ?? null,
                cooldowns: cooldownsByDay?.[dateStr] ?? {},
                paused: !canCountNow()
            };

            for (const port of livePorts) {
                try {
                    port.postMessage({ type: "LIVE_STATS", payload });
                } catch { }
            }
        });
    }, LIVE_PUSH_MS);
}

function stopLiveLoopIfNeeded() {
    if (livePorts.size > 0) return;
    if (liveIntervalId) {
        clearInterval(liveIntervalId);
        liveIntervalId = null;
    }
}

chrome.runtime.onConnect.addListener((port) => {
    if (port.name !== "popup-live") return;

    livePorts.add(port);
    startLiveLoopIfNeeded();

    port.onDisconnect.addListener(() => {
        livePorts.delete(port);
        stopLiveLoopIfNeeded();
    });
});

// --------------------
// Events
// --------------------
chrome.runtime.onInstalled.addListener(() => {
    withLock(async () => {
        await ensureTodayRecords();
        await primeTabMap();
        await injectIntoAllTrackedTabs();
        await evaluateTabsAndTiming("onInstalled");
        await evaluateCooldownsAndEnforce("onInstalledCooldowns");
    });
});

chrome.runtime.onStartup.addListener(() => {
    withLock(async () => {
        await ensureTodayRecords();
        await primeTabMap();
        await injectIntoAllTrackedTabs();
        await evaluateTabsAndTiming("onStartup");
        await evaluateCooldownsAndEnforce("onStartupCooldowns");
    });
});

chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name !== ALARM_NAME) return;
    withLock(async () => {
        await evaluateTabsAndTiming("alarm");
        await evaluateCooldownsAndEnforce("alarmCooldowns");
    });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    withLock(async () => {
        if (typeof changeInfo.url === "string") await maybeCountVisit(tabId, changeInfo.url);
        else if (changeInfo.status === "complete" && tab?.url) await maybeCountVisit(tabId, tab.url);

        await evaluateTabsAndTiming("tabs.onUpdated");
        await evaluateCooldownsAndEnforce("tabs.onUpdatedCooldowns");
    });
});

chrome.tabs.onRemoved.addListener((tabId) => {
    withLock(async () => {
        state.perTabLastSite.delete(tabId);
        await evaluateTabsAndTiming("tabs.onRemoved");
        await evaluateCooldownsAndEnforce("tabs.onRemovedCooldowns");
    });
});

chrome.windows.onFocusChanged.addListener((windowId) => {
    withLock(async () => {
        await tickNow();
        state.windowFocused = windowId !== chrome.windows.WINDOW_ID_NONE;
        state.lastTickMs = Date.now();
    });
});

chrome.idle.setDetectionInterval(60);
chrome.idle.onStateChanged.addListener((newState) => {
    withLock(async () => {
        await tickNow();
        state.idleState = newState;
        state.lastTickMs = Date.now();
    });
});

// Bootstrap
withLock(async () => {
    await ensureTodayRecords();
    await primeTabMap();
    await injectIntoAllTrackedTabs();
    await evaluateTabsAndTiming("bootstrap");
    await evaluateCooldownsAndEnforce("bootstrapCooldowns");
});
