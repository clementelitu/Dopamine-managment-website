﻿// cooldown_content.js
// Shows a translucent blocking overlay with a live countdown.
// Also attempts to pause any <video> elements periodically while cooldown is active.

let overlayEl = null;
let countdownInterval = null;
let pauseInterval = null;

function formatRemaining(ms) {
    const totalSec = Math.max(0, Math.ceil(ms / 1000));
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    return `${m}:${String(s).padStart(2, "0")}`;
}

function ensureOverlay() {
    if (overlayEl) return overlayEl;

    overlayEl = document.createElement("div");
    overlayEl.id = "__timebudget_cooldown_overlay__";
    overlayEl.style.cssText = `
    position: fixed;
    inset: 0;
    z-index: 2147483647;
    background: rgba(10, 12, 18, 0.70);
    backdrop-filter: blur(4px);
    -webkit-backdrop-filter: blur(4px);
    pointer-events: all;
    display: flex;
    align-items: center;
    justify-content: center;
  `;

    const card = document.createElement("div");
    card.style.cssText = `
    width: min(560px, calc(100vw - 32px));
    border-radius: 16px;
    border: 1px solid rgba(255,255,255,0.18);
    background: rgba(17, 24, 39, 0.92);
    box-shadow: 0 18px 60px rgba(0,0,0,0.45);
    color: #e5e7eb;
    padding: 18px 18px 16px;
    font: 14px/1.35 system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial;
  `;

    card.innerHTML = `
    <div style="display:flex; align-items:center; gap:10px; margin-bottom:10px;">
      <div style="width:34px; height:34px; border-radius:12px; display:grid; place-items:center; background: rgba(255,255,255,0.10);">⏳</div>
      <div>
        <div id="__tb_title" style="font-size:16px; font-weight:700;">Cooldown active</div>
        <div id="__tb_sub" style="color: rgba(229,231,235,0.80); font-size:12px;">You’ve reached today’s limit.</div>
      </div>
    </div>

    <div style="display:flex; gap:10px; align-items:center; margin-top:10px;">
      <div style="flex:1; padding:12px; border-radius:14px; border:1px solid rgba(255,255,255,0.14); background: rgba(255,255,255,0.06);">
        <div style="font-size:12px; color: rgba(229,231,235,0.75);">Time remaining</div>
        <div id="__tb_timer" style="font-size:28px; font-weight:800; letter-spacing:0.5px;">--:--</div>
      </div>
      <div style="width:180px; padding:12px; border-radius:14px; border:1px solid rgba(255,255,255,0.14); background: rgba(255,255,255,0.06);">
        <div style="font-size:12px; color: rgba(229,231,235,0.75);">Mode</div>
        <div id="__tb_mode" style="font-size:14px; font-weight:700;">—</div>
      </div>
    </div>

    <div style="margin-top:12px; color: rgba(229,231,235,0.70); font-size:12px;">
      This page is temporarily blocked by your Time Budget extension.
    </div>
  `;

    overlayEl.appendChild(card);

    // document_start can run before <body> exists; documentElement always exists.
    document.documentElement.appendChild(overlayEl);

    return overlayEl;
}

function removeOverlay() {
    if (countdownInterval) {
        clearInterval(countdownInterval);
        countdownInterval = null;
    }
    if (pauseInterval) {
        clearInterval(pauseInterval);
        pauseInterval = null;
    }
    if (overlayEl) {
        overlayEl.remove();
        overlayEl = null;
    }
}

function setOverlayText({ modeLabel, title, subtitle, endsAtMs }) {
    const titleEl = document.getElementById("__tb_title");
    const subEl = document.getElementById("__tb_sub");
    const modeEl = document.getElementById("__tb_mode");
    const timerEl = document.getElementById("__tb_timer");

    if (titleEl) titleEl.textContent = title;
    if (subEl) subEl.textContent = subtitle;
    if (modeEl) modeEl.textContent = modeLabel;

    const tick = () => {
        const remaining = endsAtMs - Date.now();
        if (timerEl) timerEl.textContent = formatRemaining(remaining);
        if (remaining <= 0) removeOverlay();
    };

    tick();
    if (countdownInterval) clearInterval(countdownInterval);
    countdownInterval = setInterval(tick, 500);
}

function tryPauseVideoOnce() {
    const videos = Array.from(document.querySelectorAll("video"));
    for (const v of videos) {
        try {
            if (!v.paused) v.pause();
            v.muted = true;
        } catch { }
    }
}

function startPauseLoop() {
    tryPauseVideoOnce();
    if (pauseInterval) clearInterval(pauseInterval);
    pauseInterval = setInterval(tryPauseVideoOnce, 1500);
}

function applyCooldown(payload) {
    const { active, type, endsAt } = payload ?? {};

    if (!active) {
        removeOverlay();
        return;
    }

    const endsAtMs = typeof endsAt === "number" ? endsAt : Date.now();

    ensureOverlay();

    const modeLabel = type === "eod" ? "End of day" : "15 min";
    const title = type === "eod" ? "End-of-day cooldown" : "Cooldown active";
    const subtitle =
        type === "eod"
            ? "You’ve reached both time + visit limits for today."
            : "You’ve reached the time limit. Cooldown ends soon.";

    setOverlayText({ modeLabel, title, subtitle, endsAtMs });
    startPauseLoop();
}

chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === "COOLDOWN_STATUS") applyCooldown(msg.payload);
});

// On load/injection, ask background for current status for THIS tab.
try {
    chrome.runtime.sendMessage({ type: "GET_COOLDOWN_STATUS_FOR_THIS_TAB" }).catch(() => { });
} catch { }
